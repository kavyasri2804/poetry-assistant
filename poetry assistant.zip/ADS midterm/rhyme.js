
// Function to get the last 'length' characters of a word
function getSuffix(word, length) {
    return word.slice(-length);
}

// Function to find words that rhyme with the input word based on suffix matching
function findRhymes(word, wordList, suffixLength) {
    const rhymes = [];
    const suffix = getSuffix(word, suffixLength);

    wordList.forEach(w => {
        if (w !== word && getSuffix(w, suffixLength) === suffix) {
            rhymes.push(w);
        }
    });

    return rhymes;
}

// Function to load word list
function loadWordList(callback) {
    fetch('wordlist.txt')
        .then(response => response.text())
        .then(data => {
            const wordList = data.split('\n').map(word => word.trim());
            callback(wordList);
        })
        .catch(error => {
            console.error('Error loading wordlist:', error);
            callback([]);
        });
}

// Function to handle user interaction
function findRhymesButton() {
    loadWordList(wordList => {
        const inputWord = document.getElementById('inputWord').value;
        const suffixLength = parseInt(document.getElementById('suffixLength').value); // Length of suffix to compare for rhyming
        const results = findRhymes(inputWord, wordList, suffixLength);
        document.getElementById('results').innerText = `Rhymes for '${inputWord}': ${results.join(', ')}`;
    });
}